import * as admin from 'firebase-admin';

const serviceAccount = {
  type: "service_account",
  project_id: "hostbotmanus",
  private_key_id: "cb926644587dfcd9cdf60f5e5a2a06cbd7c8cdc5",
  private_key: "-----BEGIN PRIVATE KEY-----\nMIIEvwIBADANBgkqhkiG9w0BAQEFAASCBKkwggSlAgEAAoIBAQCk2JdK3vkpM7Xh\npdEF9Lwds6lvMGqKRVFISeBEOVhd8gvRXAqcnx3WwveWiP8fpwlh5KbCAqvtmWMO\n4vMioZ84uCvivONHUC6VNYD4sMvN8HgDtixTwi7dHeg7LEmTaOduiTC7wPT7tKLE\nJNQbL05/9tdJ/DWTKX5F0Zqc21rrAte4lW5S7w1elUh2PDHrnr9CGexQsX+m+q18\niZaLyOxhV/fZo/o3O1q+hfVvRTKBRO+e7QGp7shldKfwWYaao9KEJTekDeguDtSM\nvzu0y/himzf1qTExLTReiquMVelUGqtjE268fkVoKwhD24c2h6dz4ewPDqam6sNz\n/Za5aUZRAgMBAAECggEACN8Gkk8KT90yay6sH2LOqlcINd2ASElncMlX/jfrUV/0\noptOT2QxPAThQ9rCxwprUvc2AbAY3kggSHVucfVKbygbJYA2h3iRTzKSSp/iEebA\nYKvBui6zrK7et+t/2KTfOoe7xYjibjbIAR/9wapDsld/ecHuxKkJnHqFlG4qGAZI\npGJ4BBaxD/4CO5JXcqpgW21YB4LkE4A4XREk3nPY/OTGNvXDGsQBjAexTo3jiJgJ\nwrNvwt9kTvvh87MbRfMVYaotxsXNOFfLl3XVJekhS8goby7wX4EirOf+k1Ew0vuf\nGGHtNsE1H8z5exdF5JpW+1NnsEJR+Xd1AHMgxsCbgQKBgQDT643u8f5uoGG2R8Qs\ndK4v86XHLC/fq+a7Kh8JyeM8H5+NLm9983qQnq3ImC/Dt9/APXm+TGIzdSYi7U3y\nJCv0CeBpvxhPgYANI4+MZAfuVBcLtoN+qBO6gO5xJj4XtrNUcXU9NJce2hQJkfs0\nCdfDwlvcwSQ/pUo2jsOMd8UYQQKBgQDHImi0spe1xDY44u3czE3NpPqq1mRZNWyZ\n+T6PACRHmR8btLl3aJK4bdabtvpHhzzInlggw9s7sdw4X6/zp5LbHJDJlD0VpY+p\n7oNgiuVJXeIASh3q5vz9xxivte1GAI816sjEVwytUYmKpzASAHTfC4diKGpfLr53\niz0N2VgqEQKBgQCW3drtgNnhZ8woOG8wNuDKwmoCoTJzya05EYOHNHLRGrI7kBNP\nV0aqLk0JwU4/x2dDNIC3OSmv+HZt5wLWn2mrElzw61ojP84pjGdlStFamgLOE+EJ\nCh8BZ0hYxSDvQOHp+9u69vWewSICripnoZo5guRjBB0KMmHi9T/BgIKQAQKBgQCi\nj1hiipiGbdLFxZrf8HhjNBbdd38bxB0P5QRIwJjdSga3G2V8MQX1QNU88LaHxcK9\nE2Zl+PzzUlKwQozknxunez5HEJh9H1aUJn1hRoG+zsE780VRCZflo65nYmB8EODX\n5v5WKanTowhhA/Kd/3loy4SNgOi1Ivehpy0ELTVnwQKBgQDKncmZGbx2uVoYbrXl\nQZ0TnBDv8+kkfv1UC6z6E9Lnm8fpPjHmPjgCC1RVlxvV1PBjtAvIY7knfHZiSQv1\n5UhByXrR0RigJkL7ojFnufnel20/7UIR4vNqfJTWV1A2NZyTsYql7dxh6cyp8ngw\nG158mazNiYBxIvkrBKwC5r5ifA==\n-----END PRIVATE KEY-----\n",
  client_email: "firebase-adminsdk-fbsvc@hostbotmanus.iam.gserviceaccount.com",
  client_id: "108076397138699452357",
  auth_uri: "https://accounts.google.com/o/oauth2/auth",
  token_uri: "https://oauth2.googleapis.com/token",
  auth_provider_x509_cert_url: "https://www.googleapis.com/oauth2/v1/certs",
  client_x509_cert_url: "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-fbsvc%40hostbotmanus.iam.gserviceaccount.com",
  universe_domain: "googleapis.com"
};

let firebaseApp: admin.app.App | null = null;

export function getFirebaseAdmin() {
  if (!firebaseApp) {
    firebaseApp = admin.initializeApp({
      credential: admin.credential.cert(serviceAccount as admin.ServiceAccount),
      projectId: 'hostbotmanus',
    });
  }
  return firebaseApp;
}

export function getFirestore() {
  const app = getFirebaseAdmin();
  return admin.firestore(app);
}

export function getAuth() {
  const app = getFirebaseAdmin();
  return admin.auth(app);
}
