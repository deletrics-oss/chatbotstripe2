import Stripe from "stripe";
import { STRIPE_PRODUCTS, getPlanByPriceId } from "./products";

if (!process.env.STRIPE_SECRET_KEY) {
  throw new Error("STRIPE_SECRET_KEY não configurada");
}

export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: "2025-11-17.clover",
});

export async function createCheckoutSession(params: {
  priceId: string;
  userId: number;
  userEmail: string;
  userName: string;
  origin: string;
}) {
  const { priceId, userId, userEmail, userName, origin } = params;

  const session = await stripe.checkout.sessions.create({
    mode: "subscription",
    payment_method_types: ["card"],
    line_items: [
      {
        price: priceId,
        quantity: 1,
      },
    ],
    customer_email: userEmail,
    client_reference_id: userId.toString(),
    metadata: {
      user_id: userId.toString(),
      customer_email: userEmail,
      customer_name: userName,
    },
    allow_promotion_codes: true,
    success_url: `${origin}/dashboard?payment=success`,
    cancel_url: `${origin}/dashboard?payment=cancelled`,
  });

  return session;
}

export async function handleWebhookEvent(event: Stripe.Event) {
  console.log(`[Stripe Webhook] Evento recebido: ${event.type}`);

  // Detectar eventos de teste
  if (event.id.startsWith("evt_test_")) {
    console.log("[Webhook] Test event detected, returning verification response");
    return { verified: true };
  }

  switch (event.type) {
    case "checkout.session.completed": {
      const session = event.data.object as Stripe.Checkout.Session;
      await handleCheckoutCompleted(session);
      break;
    }

    case "customer.subscription.created":
    case "customer.subscription.updated": {
      const subscription = event.data.object as Stripe.Subscription;
      await handleSubscriptionChange(subscription);
      break;
    }

    case "customer.subscription.deleted": {
      const subscription = event.data.object as Stripe.Subscription;
      await handleSubscriptionCancelled(subscription);
      break;
    }

    case "invoice.paid": {
      const invoice = event.data.object as Stripe.Invoice;
      await handleInvoicePaid(invoice);
      break;
    }

    case "invoice.payment_failed": {
      const invoice = event.data.object as Stripe.Invoice;
      await handleInvoicePaymentFailed(invoice);
      break;
    }

    default:
      console.log(`[Webhook] Evento não tratado: ${event.type}`);
  }

  return { received: true };
}

async function handleCheckoutCompleted(session: Stripe.Checkout.Session) {
  console.log(`[Webhook] Checkout concluído: ${session.id}`);

  const userId = session.metadata?.user_id;
  if (!userId) {
    console.error("[Webhook] user_id não encontrado no metadata");
    return;
  }

  const subscriptionId =
    typeof session.subscription === "string"
      ? session.subscription
      : session.subscription?.id;

  if (!subscriptionId) {
    console.error("[Webhook] Subscription ID não encontrado");
    return;
  }

  // Buscar detalhes da assinatura
  const subscription = await stripe.subscriptions.retrieve(subscriptionId);
  const priceId = subscription.items.data[0]?.price.id;

  if (!priceId) {
    console.error("[Webhook] Price ID não encontrado");
    return;
  }

  const plan = getPlanByPriceId(priceId);
  if (!plan) {
    console.error(`[Webhook] Plano não encontrado para price_id: ${priceId}`);
    return;
  }

  // Atualizar tenant no banco de dados
  const { updateTenantByUserId } = await import("./db");
  await updateTenantByUserId(parseInt(userId), {
    plan,
    stripeCustomerId: session.customer as string,
    stripeSubscriptionId: subscriptionId,
    subscriptionStatus: subscription.status as "active" | "canceled" | "past_due" | "trialing",
    trialEndsAt: null, // Remover trial ao assinar
  });

  console.log(`[Webhook] Tenant atualizado para plano ${plan}`);
}

async function handleSubscriptionChange(subscription: Stripe.Subscription) {
  console.log(`[Webhook] Assinatura atualizada: ${subscription.id}`);

  const customerId = subscription.customer as string;
  const priceId = subscription.items.data[0]?.price.id;

  if (!priceId) {
    console.error("[Webhook] Price ID não encontrado");
    return;
  }

  const plan = getPlanByPriceId(priceId);
  if (!plan) {
    console.error(`[Webhook] Plano não encontrado para price_id: ${priceId}`);
    return;
  }

  // Atualizar tenant no banco de dados
  const { updateTenantByStripeCustomerId } = await import("./db");
  await updateTenantByStripeCustomerId(customerId, {
    plan,
    stripeSubscriptionId: subscription.id,
    subscriptionStatus: subscription.status as "active" | "canceled" | "past_due" | "trialing",
  });

  console.log(`[Webhook] Assinatura atualizada para plano ${plan}`);
}

async function handleSubscriptionCancelled(subscription: Stripe.Subscription) {
  console.log(`[Webhook] Assinatura cancelada: ${subscription.id}`);

  const customerId = subscription.customer as string;

  // Reverter para plano Free
  const { updateTenantByStripeCustomerId } = await import("./db");
  await updateTenantByStripeCustomerId(customerId, {
    plan: "free",
    stripeSubscriptionId: null,
    subscriptionStatus: "canceled",
  });

  console.log(`[Webhook] Tenant revertido para plano Free`);
}

async function handleInvoicePaid(invoice: Stripe.Invoice) {
  console.log(`[Webhook] Fatura paga: ${invoice.id}`);
  // Lógica adicional se necessário (ex: enviar e-mail de confirmação)
}

async function handleInvoicePaymentFailed(invoice: Stripe.Invoice) {
  console.log(`[Webhook] Falha no pagamento da fatura: ${invoice.id}`);
  // Lógica adicional se necessário (ex: notificar usuário)
}
