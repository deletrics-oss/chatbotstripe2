import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";
import { createCheckoutSession } from "./stripe";
import { STRIPE_PRODUCTS } from "./products";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Tenant management
  tenant: router({
    get: protectedProcedure.query(async ({ ctx }) => {
      return await db.getTenantByUserId(ctx.user.id);
    }),
    create: protectedProcedure.mutation(async ({ ctx }) => {
      const existing = await db.getTenantByUserId(ctx.user.id);
      if (existing) {
        throw new Error("Tenant já existe para este usuário");
      }
      const tenantId = await db.createTenant({
        userId: ctx.user.id,
        plan: "free",
        maxSessions: 1,
        trialEndsAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 dias
      });
      return { success: true, tenantId };
    }),
  }),

  // WhatsApp sessions
  sessions: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      const tenant = await db.getTenantByUserId(ctx.user.id);
      if (!tenant) return [];
      return await db.getSessionsByTenantId(tenant.id);
    }),
    create: protectedProcedure
      .input(z.object({ name: z.string(), sessionId: z.string() }))
      .mutation(async ({ ctx, input }) => {
        const tenant = await db.getTenantByUserId(ctx.user.id);
        if (!tenant) {
          throw new Error("Tenant não encontrado");
        }
        const existingSessions = await db.getSessionsByTenantId(tenant.id);
        if (existingSessions.length >= tenant.maxSessions) {
          throw new Error(
            `Você atingiu o limite de ${tenant.maxSessions} sessões do seu plano`
          );
        }
        const sessionId = await db.createSession({
          tenantId: tenant.id,
          sessionId: input.sessionId,
          name: input.name,
          status: "initializing",
        });
        // Iniciar sessão WhatsApp
        const { createSession } = await import("./whatsappManager");
        await createSession(input.sessionId, tenant.id);
        return { success: true, sessionId };
      }),
    delete: protectedProcedure
      .input(z.object({ sessionId: z.string() }))
      .mutation(async ({ ctx, input }) => {
        const tenant = await db.getTenantByUserId(ctx.user.id);
        if (!tenant) {
          throw new Error("Tenant não encontrado");
        }
        const session = await db.getSessionBySessionId(input.sessionId);
        if (!session || session.tenantId !== tenant.id) {
          throw new Error("Sessão não encontrada");
        }
        // Destruir sessão WhatsApp
        const { destroySession } = await import("./whatsappManager");
        await destroySession(input.sessionId);
        await db.deleteSession(input.sessionId);
        return { success: true };
      }),
    status: protectedProcedure
      .input(z.object({ sessionId: z.string() }))
      .query(async ({ input }) => {
        const { getSessionStatus } = await import("./whatsappManager");
        return getSessionStatus(input.sessionId);      }),

    updateLogic: protectedProcedure
      .input(
        z.object({
          sessionId: z.string(),
          logicId: z.number().nullable(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const tenant = await db.getTenantByUserId(ctx.user.id);
        if (!tenant) {
          throw new Error("Tenant não encontrado");
        }

        const session = await db.getSessionBySessionId(input.sessionId);
        if (!session || session.tenantId !== tenant.id) {
          throw new Error("Sessão não encontrada");
        }

        await db.updateSession(input.sessionId, { logicId: input.logicId });
        return { success: true };
      }),
  }),

  // Lógicas
  logics: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      const tenant = await db.getTenantByUserId(ctx.user.id);
      if (!tenant) return [];
      return await db.getLogicsByTenantId(tenant.id);
    }),
    create: protectedProcedure
      .input(
        z.object({
          name: z.string(),
          type: z.enum(["json_static", "txt_ai"]),
          content: z.string(),
          description: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const tenant = await db.getTenantByUserId(ctx.user.id);
        if (!tenant) {
          throw new Error("Tenant não encontrado");
        }
        const logicId = await db.createLogic({
          tenantId: tenant.id,
          name: input.name,
          type: input.type,
          content: input.content,
          description: input.description,
        });
        return { success: true, logicId };
      }),
    delete: protectedProcedure
      .input(z.object({ logicId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const tenant = await db.getTenantByUserId(ctx.user.id);
        if (!tenant) {
          throw new Error("Tenant não encontrado");
        }
        const logic = await db.getLogicById(input.logicId);
        if (!logic || logic.tenantId !== tenant.id) {
          throw new Error("Lógica não encontrada");
        }
        await db.deleteLogic(input.logicId);
        return { success: true };
      }),

    generateWithGemini: protectedProcedure
      .input(
        z.object({
          prompt: z.string(),
          type: z.enum(["json_static", "txt_ai"]),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const { invokeLLM } = await import("./_core/llm");

        const systemPrompt =
          input.type === "json_static"
            ? `Você é um especialista em criar lógicas JSON para chatbots. 
Gere um JSON válido no formato: {"keywords": ["palavra1", "palavra2"], "response": "Resposta do bot"}
Retorne APENAS o JSON, sem explicações adicionais.`
            : `Você é um especialista em criar prompts para assistentes de IA.
Crie um prompt de sistema (system prompt) em texto puro que defina o comportamento do assistente.
Retorne APENAS o texto do prompt, sem explicações adicionais.`;

        const result = await invokeLLM({
          messages: [
            { role: "system", content: systemPrompt },
            { role: "user", content: input.prompt },
          ],
        });

        let content = result.choices[0]?.message?.content || "";

        // Limpar markdown code blocks se existirem
        content = content.replace(/```json\n?/g, "").replace(/```txt\n?/g, "").replace(/```\n?/g, "").trim();

        // Gerar nome baseado no prompt
        const nameResult = await invokeLLM({
          messages: [
            { role: "user", content: `Crie um nome curto (máximo 30 caracteres) para esta lógica de chatbot: ${input.prompt}. Retorne APENAS o nome, sem explicações.` },
          ],
        });
        const name = (nameResult.choices[0]?.message?.content || "Nova Lógica").trim().replace(/["']/g, "");

        return { content, name };
      }),
  }),

  // Stripe
  stripe: router({
    createCheckout: protectedProcedure
      .input(z.object({ plan: z.enum(["basic", "premium"]) }))
      .mutation(async ({ ctx, input }) => {
        const priceId =
          input.plan === "basic"
            ? STRIPE_PRODUCTS.BASIC.price_id
            : STRIPE_PRODUCTS.PREMIUM.price_id;

        const session = await createCheckoutSession({
          priceId,
          userId: ctx.user.id,
          userEmail: ctx.user.email || "",
          userName: ctx.user.name || "",
          origin: `${ctx.req.protocol}://${ctx.req.headers.host}`,
        });

        return { url: session.url };
      }),
  }),
});

export type AppRouter = typeof appRouter;
