import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(): { ctx: TrpcContext } {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };

  return { ctx };
}

describe("logics.generateWithGemini", () => {
  it("should generate JSON logic with Gemini", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.logics.generateWithGemini({
      prompt: "Crie uma lógica que responda 'Olá' quando o usuário enviar 'oi'",
      type: "json_static",
    });

    // Verificar que o conteúdo e o nome foram gerados
    expect(result).toHaveProperty("content");
    expect(result).toHaveProperty("name");
    expect(typeof result.content).toBe("string");
    expect(typeof result.name).toBe("string");
    expect(result.content.length).toBeGreaterThan(0);
    expect(result.name.length).toBeGreaterThan(0);
  }, 30000); // Timeout de 30 segundos para chamadas de IA

  it("should generate TXT logic with Gemini", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.logics.generateWithGemini({
      prompt: "Crie um assistente que ajuda clientes a escolher produtos",
      type: "txt_ai",
    });

    // Verificar que o conteúdo e o nome foram gerados
    expect(result).toHaveProperty("content");
    expect(result).toHaveProperty("name");
    expect(typeof result.content).toBe("string");
    expect(typeof result.name).toBe("string");
    expect(result.content.length).toBeGreaterThan(0);
    expect(result.name.length).toBeGreaterThan(0);
  }, 30000); // Timeout de 30 segundos para chamadas de IA
});
