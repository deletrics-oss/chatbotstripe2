import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(): { ctx: TrpcContext } {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };

  return { ctx };
}

describe("tenant.get", () => {
  it("should return tenant for authenticated user", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.tenant.get();

    // O tenant pode ou não existir dependendo do estado do banco de dados
    // Apenas verificamos que a query não lança erro
    expect(result).toBeDefined();
  });
});

describe("sessions.list", () => {
  it("should return empty array when no tenant exists", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.sessions.list();

    // Se não houver tenant, deve retornar array vazio
    expect(Array.isArray(result)).toBe(true);
  });
});

describe("logics.list", () => {
  it("should return empty array when no tenant exists", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.logics.list();

    // Se não houver tenant, deve retornar array vazio
    expect(Array.isArray(result)).toBe(true);
  });
});
