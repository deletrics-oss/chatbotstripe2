import { Client, LocalAuth, MessageMedia } from "whatsapp-web.js";
import { GoogleGenerativeAI } from "@google/generative-ai";
import qrcode from "qrcode";
import * as db from "./db";

// Inicializar Gemini API
let genAI: GoogleGenerativeAI | null = null;
if (process.env.GEMINI_API_KEY) {
  genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
}

// Armazenar sessões ativas em memória
interface SessionData {
  client: Client;
  status: string;
  qrCode: string | null;
  pausedChats: string[];
}

const sessions: Map<string, SessionData> = new Map();

// WebSocket para comunicação real-time
let wss: any = null;

export function setWss(webSocketServer: any) {
  wss = webSocketServer;
}

function broadcastEvent(event: any) {
  if (!wss) return;
  const data = JSON.stringify(event);
  wss.clients.forEach((client: any) => {
    if (client.readyState === client.OPEN) {
      client.send(data);
    }
  });
}

// Motor de regras (JSON estático)
function runRuleBasedEngine(message: any, logicContent: string) {
  try {
    const logicData = JSON.parse(logicContent);
    const userMessage = message.body.toLowerCase().trim();

    for (const rule of logicData.rules) {
      const foundKeyword = rule.keywords.find(
        (keyword: string) => userMessage === keyword.toLowerCase()
      );
      if (foundKeyword) {
        return {
          handled: true,
          reply: rule.reply,
          shouldPause: rule.pause_bot_after_reply === true,
          image_url: rule.image_url || null,
        };
      }
    }

    if (logicData.default_reply) {
      return {
        handled: true,
        reply: logicData.default_reply,
        shouldPause: false,
        image_url: null,
      };
    }
  } catch (error) {
    console.error("Erro ao processar lógica JSON:", error);
  }
  return { handled: false };
}

// Criar sessão WhatsApp
export async function createSession(sessionId: string, tenantId: number) {
  console.log(`[WhatsappManager] Criando sessão: ${sessionId}`);

  const client = new Client({
    authStrategy: new LocalAuth({ clientId: sessionId }),
    puppeteer: {
      args: [
        "--no-sandbox",
        "--disable-setuid-sandbox",
        "--disable-dev-shm-usage",
        "--disable-accelerated-2d-canvas",
        "--no-first-run",
        "--no-zygote",
        "--disable-gpu",
      ],
    },
  });

  sessions.set(sessionId, {
    client,
    status: "INITIALIZING",
    qrCode: null,
    pausedChats: [],
  });

  // Atualizar status no banco de dados
  await db.updateSession(sessionId, { status: "initializing" });

  broadcastEvent({ type: "status_update", sessionId, status: "INITIALIZING" });

  client.on("qr", async (qr) => {
    console.log(`[${sessionId}] QR Code recebido.`);
    const session = sessions.get(sessionId);
    if (session) {
      session.status = "QR_PENDING";
      const qrDataUrl = await qrcode.toDataURL(qr);
      session.qrCode = qrDataUrl;

      // Atualizar QR Code no banco de dados
      await db.updateSession(sessionId, {
        status: "qr_pending",
        qrCode: qrDataUrl,
      });

      broadcastEvent({
        type: "status_update",
        sessionId,
        status: "QR_PENDING",
        qrCode: qrDataUrl,
      });
    }
  });

  client.on("ready", async () => {
    console.log(`[${sessionId}] Cliente pronto e conectado.`);
    const session = sessions.get(sessionId);
    if (session) {
      session.status = "READY";
      session.qrCode = null;

      // Atualizar status no banco de dados
      await db.updateSession(sessionId, { status: "ready", qrCode: null });

      broadcastEvent({ type: "status_update", sessionId, status: "READY" });
    }
  });

  client.on("disconnected", async (reason) => {
    console.warn(`[${sessionId}] Cliente desconectado:`, reason);
    const session = sessions.get(sessionId);
    if (session && session.status !== "DESTROYING") {
      await destroySession(sessionId);
    }
  });

  client.on("message", async (message) => {
    const userNumber = message.from;
    if (userNumber.endsWith("@g.us") || message.isStatus || message.fromMe) {
      return;
    }

    const session = sessions.get(sessionId);
    if (!session) return;

    // Lógica de pausa
    const isPaused = session.pausedChats.includes(userNumber);
    const userMessageLower = message.body.toLowerCase().trim();
    const unpauseKeywords = [
      "menu",
      "ajuda",
      "inicio",
      "início",
      "start",
      "voltar",
      "sair",
      "opcoes",
      "opções",
      "0",
    ];

    if (isPaused) {
      if (unpauseKeywords.includes(userMessageLower)) {
        session.pausedChats = session.pausedChats.filter(
          (id) => id !== userNumber
        );
        console.log(`[${sessionId}] Chat ${userNumber} foi REATIVADO.`);
      } else {
        console.log(
          `[${sessionId}] Chat ${userNumber} está pausado. Ignorando mensagem.`
        );
        return;
      }
    }

    // Comando de status
    if (message.body.toLowerCase() === "/status") {
      const statusMessage = `Bot Conectado!\\n\\n- *Dispositivo:* ${sessionId}\\n- *Status WhatsApp:* OK\\n- *Servidor:* OK\\n- *Gemini AI:* ${genAI ? "OK" : "ERRO"}`;
      await client.sendMessage(userNumber, statusMessage);
      broadcastEvent({
        type: "new_message",
        sessionId,
        from: userNumber,
        body: message.body,
        timestamp: new Date().toISOString(),
      });
      return;
    }

    // Buscar lógica associada à sessão
    const sessionData = await db.getSessionBySessionId(sessionId);
    if (!sessionData) return;

    let logicContent: string | null = null;
    let logicType: string | null = null;

    if (sessionData.logicId) {
      const logic = await db.getLogicById(sessionData.logicId);
      if (logic) {
        logicContent = logic.content;
        logicType = logic.type;
      }
    }

    // Motor de regras (JSON)
    if (logicType === "json_static" && logicContent) {
      const ruleResult = runRuleBasedEngine(message, logicContent);
      if (ruleResult.handled) {
        broadcastEvent({
          type: "new_message",
          sessionId,
          from: userNumber,
          body: message.body,
          timestamp: new Date().toISOString(),
        });

        // Enviar imagem se existir
        if (ruleResult.image_url) {
          try {
            const media = await MessageMedia.fromUrl(ruleResult.image_url, {
              unsafeMime: true,
            });
            await client.sendMessage(userNumber, media, {
              caption: ruleResult.reply,
            });
            console.log(`[${sessionId}] Resposta com imagem enviada.`);
          } catch (imgError) {
            console.error(
              `[${sessionId}] Falha ao enviar imagem. Enviando só texto.`,
              imgError
            );
            await message.reply(ruleResult.reply);
          }
        } else {
          await message.reply(ruleResult.reply);
        }

        broadcastEvent({
          type: "new_message",
          sessionId,
          from: "BOT",
          to: userNumber,
          body: ruleResult.reply,
          timestamp: new Date().toISOString(),
        });

        // Pausar se necessário
        if (ruleResult.shouldPause) {
          if (!session.pausedChats.includes(userNumber)) {
            session.pausedChats.push(userNumber);
            console.log(`[${sessionId}] Chat ${userNumber} foi PAUSADO.`);
          }
        }

        // Salvar mensagem no banco de dados
        await db.createMessage({
          sessionId: sessionData.id,
          from: userNumber,
          to: "BOT",
          body: message.body,
        });

        return;
      }
    }

    // Fallback para Gemini AI
    broadcastEvent({
      type: "new_message",
      sessionId,
      from: userNumber,
      body: message.body,
      timestamp: new Date().toISOString(),
    });

    console.log(
      `[${sessionId}] Nenhuma regra encontrada, usando Gemini para: ${message.body}`
    );

    try {
      if (!genAI) throw new Error("API do Gemini não inicializada.");

      let knowledge = "";
      if (logicType === "txt_ai" && logicContent) {
        knowledge = logicContent;
      }

      let systemInstruction;
      if (knowledge.trim() === "") {
        systemInstruction = `Você é um assistente virtual amigável e prestativo. Responda em português do Brasil.`;
      } else {
        systemInstruction = `Você é um assistente virtual amigável e prestativo.
        
        Suas regras de resposta são:
        1. Use APENAS a informação da "BASE DE CONHECIMENTO" fornecida abaixo para responder perguntas específicas.
        2. Se a pergunta não estiver relacionada à base de conhecimento, responda educadamente que você só pode ajudar com esses assuntos.
        
        --- BASE DE CONHECIMENTO ---
        ${knowledge}
        --- FIM DA BASE DE CONHECIMENTO ---`;
      }

      const model = genAI.getGenerativeModel({ model: "gemini-pro" });
      const initialHistory = [
        { role: "user", parts: [{ text: systemInstruction }] },
        {
          role: "model",
          parts: [{ text: "Ok, entendi minhas instruções. Estou pronto!" }],
        },
      ];
      const chat = model.startChat({ history: initialHistory });
      const result = await chat.sendMessage(message.body);
      const textResponse = result.response.text();

      await client.sendMessage(userNumber, textResponse);
      broadcastEvent({
        type: "new_message",
        sessionId,
        from: "BOT",
        to: userNumber,
        body: textResponse,
        timestamp: new Date().toISOString(),
      });

      // Salvar mensagem no banco de dados
      await db.createMessage({
        sessionId: sessionData.id,
        from: userNumber,
        to: "BOT",
        body: message.body,
      });
    } catch (error) {
      console.error(`[${sessionId}] Erro ao processar com Gemini:`, error);
      await message.reply(
        "Desculpe, ocorreu um erro ao processar sua mensagem. Tente novamente mais tarde."
      );
    }
  });

  client.initialize();
}

// Destruir sessão
export async function destroySession(sessionId: string) {
  console.log(`[WhatsappManager] Destruindo sessão: ${sessionId}`);
  const session = sessions.get(sessionId);
  if (session) {
    session.status = "DESTROYING";
    try {
      await session.client.destroy();
    } catch (error) {
      console.error(`[${sessionId}] Erro ao destruir cliente:`, error);
    }
    sessions.delete(sessionId);

    // Atualizar status no banco de dados
    await db.updateSession(sessionId, { status: "destroyed" });

    broadcastEvent({ type: "status_update", sessionId, status: "DESTROYED" });
  }
}

// Obter status da sessão
export function getSessionStatus(sessionId: string) {
  const session = sessions.get(sessionId);
  if (!session) return null;
  return {
    status: session.status,
    qrCode: session.qrCode,
  };
}

// Inicializar todas as sessões ativas ao iniciar o servidor
export async function initializeAllSessions() {
  console.log("[WhatsappManager] Inicializando todas as sessões ativas...");
  // Buscar todas as sessões com status "ready" ou "qr_pending"
  // Nota: Isso requer uma função no db.ts que busque todas as sessões ativas
  // Por enquanto, vamos deixar vazio e implementar quando necessário
  console.log("[WhatsappManager] Nenhuma sessão para inicializar no momento.");
}
