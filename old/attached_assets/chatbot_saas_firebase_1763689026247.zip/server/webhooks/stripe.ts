import express from "express";
import { stripe, handleWebhookEvent } from "../stripe";

export const stripeWebhookRouter = express.Router();

// IMPORTANTE: Este endpoint DEVE usar express.raw() para verificação de assinatura
stripeWebhookRouter.post(
  "/api/stripe/webhook",
  express.raw({ type: "application/json" }),
  async (req, res) => {
    const sig = req.headers["stripe-signature"];

    if (!sig) {
      console.error("[Stripe Webhook] Assinatura ausente");
      return res.status(400).send("Webhook Error: Missing signature");
    }

    let event;

    try {
      event = stripe.webhooks.constructEvent(
        req.body,
        sig,
        process.env.STRIPE_WEBHOOK_SECRET!
      );
    } catch (err: any) {
      console.error(`[Stripe Webhook] Erro de verificação: ${err.message}`);
      return res.status(400).send(`Webhook Error: ${err.message}`);
    }

    try {
      const result = await handleWebhookEvent(event);
      res.json(result);
    } catch (error: any) {
      console.error(`[Stripe Webhook] Erro ao processar evento: ${error.message}`);
      res.status(500).send(`Webhook Error: ${error.message}`);
    }
  }
);
