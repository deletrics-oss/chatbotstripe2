// Definição dos produtos e preços do Stripe

export const STRIPE_PRODUCTS = {
  FREE: {
    name: "Plano Free",
    description: "30 dias grátis - 1 sessão WhatsApp, lógicas JSON estáticas",
    maxSessions: 1,
    features: ["1 sessão WhatsApp", "Lógicas JSON estáticas", "30 dias grátis"],
    price: 0,
    interval: "month",
    // Não precisa de price_id pois é grátis
  },
  BASIC: {
    name: "Plano Básico",
    description: "1 sessão WhatsApp, lógicas JSON estáticas, suporte prioritário",
    maxSessions: 1,
    features: [
      "1 sessão WhatsApp",
      "Lógicas JSON estáticas",
      "Suporte prioritário",
    ],
    price: 29.9,
    interval: "month",
    // Price ID será criado no Stripe Dashboard
    price_id: process.env.STRIPE_BASIC_PRICE_ID || "price_basic_monthly",
  },
  PREMIUM: {
    name: "Plano Premium",
    description:
      "3 sessões WhatsApp, lógicas JSON + IA, bot inteligente com Gemini",
    maxSessions: 3,
    features: [
      "3 sessões WhatsApp",
      "Lógicas JSON + IA",
      "Bot inteligente com Gemini",
      "Suporte prioritário",
    ],
    price: 99.9,
    interval: "month",
    // Price ID será criado no Stripe Dashboard
    price_id: process.env.STRIPE_PREMIUM_PRICE_ID || "price_premium_monthly",
  },
} as const;

export type PlanType = "free" | "basic" | "premium";

export function getPlanByPriceId(priceId: string): PlanType | null {
  if (priceId === STRIPE_PRODUCTS.BASIC.price_id) return "basic";
  if (priceId === STRIPE_PRODUCTS.PREMIUM.price_id) return "premium";
  return null;
}

export function getMaxSessionsByPlan(plan: PlanType): number {
  switch (plan) {
    case "free":
      return STRIPE_PRODUCTS.FREE.maxSessions;
    case "basic":
      return STRIPE_PRODUCTS.BASIC.maxSessions;
    case "premium":
      return STRIPE_PRODUCTS.PREMIUM.maxSessions;
    default:
      return 1;
  }
}
