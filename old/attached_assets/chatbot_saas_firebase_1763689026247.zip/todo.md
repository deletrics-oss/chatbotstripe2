# Chatbot SaaS Platform - TODO

## Fase 1: Configuração Inicial ✅
- [x] Inicializar projeto web full-stack
- [x] Configurar estrutura base

## Fase 2: Autenticação e Multilocação (Tenant)
- [x] Configurar Firebase Admin SDK
- [x] Criar schema de banco de dados para tenants
- [x] Implementar sistema de autenticação com Firebase Auth
- [x] Criar lógica de criação de tenant ao cadastrar novo usuário
- [x] Implementar isolamento de dados por tenant (user.uid)
- [x] Configurar Regras de Segurança do Firestore

## Fase 3: Migração do Código Existente
- [x] Migrar serviço de WhatsApp (whatsappManager.js)
- [x] Migrar motor de regras (JSON)
- [x] Migrar motor de IA (Gemini)
- [x] Migrar sistema de QR Code
- [x] Migrar WebSocket para comunicação real-time
- [x] Adaptar rotas da API existente

## Fase 4: Integração Stripe
- [x] Configurar Stripe SDK
- [x] Criar endpoints de checkout (3 planos)
- [x] Implementar Webhook do Stripe (Cloud Functions)
- [x] Criar lógica de atualização de plano no Firestore
- [x] Implementar controle de acesso baseado em plano
- [ ] Testar fluxo completo de pagamento (aguardando configuração de Price IDs)

## Fase 5: Aba Gemini (Geração de Lógicas)
- [x] Criar interface UI para gerador de lógicas
- [x] Implementar backend (Cloud Functions) para chamar API Gemini
- [x] Criar prompt de engenharia reversa para gerar JSON
- [x] Criar prompt de engenharia reversa para gerar TXT
- [x] Implementar funcionalidade de salvar lógica no Firestore
- [x] Associar lógicas geradas às sessões WhatsApp

## Fase 6: Design (UX/UI)
- [x] Criar layout do dashboard principal
- [x] Implementar página de gerenciamento de sessões WhatsApp
- [x] Criar página de visualização de lógicas
- [x] Implementar página de configurações de plano/assinatura (landing page)
- [x] Adicionar componentes de QR Code
- [x] Melhorar tipografia e espaçamento
- [x] Garantir responsividade (mobile, tablet, desktop)
- [x] Adicionar animações e micro-interações
- [x] Implementar seletor de lógica para associar às sessões WhatsApp

## Fase 7: Testes e Validação
- [ ] Testar cadastro de novo usuário
- [ ] Testar criação de sessão WhatsApp
- [ ] Testar geração de QR Code
- [ ] Testar motor de regras (JSON)
- [ ] Testar motor de IA (Gemini)
- [ ] Testar fluxo de pagamento Stripe
- [ ] Testar geração de lógicas com Gemini
- [ ] Testar isolamento de dados entre tenants

## Fase 8: Deploy e Entrega
- [ ] Configurar Firebase Hosting
- [ ] Configurar Cloud Functions
- [ ] Criar repositório no GitHub
- [ ] Documentar instalação e configuração
- [ ] Realizar deploy no Firebase
- [ ] Entregar código no GitHub

## Fase 9: Correções e Redesign
- [ ] Corrigir erro da API Gemini (adicionar GEMINI_API_KEY como variável de ambiente)
- [ ] Redesenhar dashboard para página única (estilo do sistema original)
- [ ] Aplicar design com fundo azul gradiente e glassmorphism
- [ ] Centralizar todos os componentes em uma única view
- [ ] Manter funcionalidade de QR Code, lógicas, sessões e Gemini
