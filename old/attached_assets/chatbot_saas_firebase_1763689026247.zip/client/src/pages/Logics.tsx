import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { Loader2, Plus, Trash2, Bot, FileJson, FileText } from "lucide-react";
import { useLocation } from "wouter";

export default function Logics() {
  const { user, loading: authLoading, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const [selectedType, setSelectedType] = useState<"json_static" | "txt_ai">("json_static");
  const [logicName, setLogicName] = useState("");
  const [logicContent, setLogicContent] = useState("");
  const [geminiPrompt, setGeminiPrompt] = useState("");

  // Redirecionar se não autenticado
  if (!authLoading && !isAuthenticated) {
    setLocation("/");
    return null;
  }

  const { data: logics, isLoading, refetch } = trpc.logics.list.useQuery();

  const createLogicMutation = trpc.logics.create.useMutation({
    onSuccess: () => {
      toast.success("Lógica criada com sucesso!");
      setLogicName("");
      setLogicContent("");
      refetch();
    },
    onError: (error) => {
      toast.error(`Erro: ${error.message}`);
    },
  });

  const deleteLogicMutation = trpc.logics.delete.useMutation({
    onSuccess: () => {
      toast.success("Lógica excluída com sucesso!");
      refetch();
    },
    onError: (error) => {
      toast.error(`Erro: ${error.message}`);
    },
  });

  const generateLogicMutation = trpc.logics.generateWithGemini.useMutation({
    onSuccess: (data: { content: string; name: string }) => {
      toast.success("Lógica gerada com sucesso!");
      setLogicContent(data.content);
      setLogicName(data.name || "");
    },
    onError: (error: any) => {
      toast.error(`Erro: ${error.message}`);
    },
  });

  const handleCreateLogic = () => {
    if (!logicName || !logicContent) {
      toast.error("Preencha o nome e o conteúdo da lógica");
      return;
    }

    createLogicMutation.mutate({
      name: logicName,
      type: selectedType,
      content: logicContent,
    });
  };

  const handleGenerateLogic = () => {
    if (!geminiPrompt) {
      toast.error("Descreva a lógica que você deseja gerar");
      return;
    }

    generateLogicMutation.mutate({
      prompt: geminiPrompt,
      type: selectedType,
    });
  };

  const handleDeleteLogic = (logicId: number) => {
    if (confirm("Tem certeza que deseja excluir esta lógica?")) {
      deleteLogicMutation.mutate({ logicId });
    }
  };

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-6xl mx-auto">
        <div className="mb-6">
          <h1 className="text-3xl font-bold">Gerenciamento de Lógicas</h1>
          <p className="text-muted-foreground">
            Crie e gerencie lógicas JSON (estáticas) e TXT (IA) para seus chatbots
          </p>
        </div>

        <Tabs defaultValue="create" className="mb-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="create">Criar Manualmente</TabsTrigger>
            <TabsTrigger value="gemini">
              <Bot className="w-4 h-4 mr-2" />
              Gerar com IA
            </TabsTrigger>
            <TabsTrigger value="list">Minhas Lógicas</TabsTrigger>
          </TabsList>

          <TabsContent value="create" className="space-y-4">
            <Card className="p-6">
              <div className="space-y-4">
                <div>
                  <Label htmlFor="logic-name">Nome da Lógica</Label>
                  <Input
                    id="logic-name"
                    placeholder="Ex: Atendimento Padrão"
                    value={logicName}
                    onChange={(e) => setLogicName(e.target.value)}
                  />
                </div>

                <div>
                  <Label>Tipo de Lógica</Label>
                  <div className="flex gap-4 mt-2">
                    <Button
                      variant={selectedType === "json_static" ? "default" : "outline"}
                      onClick={() => setSelectedType("json_static")}
                    >
                      <FileJson className="w-4 h-4 mr-2" />
                      JSON (Estático)
                    </Button>
                    <Button
                      variant={selectedType === "txt_ai" ? "default" : "outline"}
                      onClick={() => setSelectedType("txt_ai")}
                    >
                      <FileText className="w-4 h-4 mr-2" />
                      TXT (IA)
                    </Button>
                  </div>
                </div>

                <div>
                  <Label htmlFor="logic-content">Conteúdo</Label>
                  <Textarea
                    id="logic-content"
                    placeholder={
                      selectedType === "json_static"
                        ? '{"keywords": ["oi", "olá"], "response": "Olá! Como posso ajudar?"}'
                        : "Você é um assistente prestativo que responde perguntas sobre produtos."
                    }
                    value={logicContent}
                    onChange={(e) => setLogicContent(e.target.value)}
                    rows={10}
                    className="font-mono text-sm"
                  />
                </div>

                <Button
                  onClick={handleCreateLogic}
                  disabled={createLogicMutation.isPending}
                  className="w-full"
                >
                  {createLogicMutation.isPending && (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  )}
                  <Plus className="w-4 h-4 mr-2" />
                  Criar Lógica
                </Button>
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="gemini" className="space-y-4">
            <Card className="p-6">
              <div className="space-y-4">
                <div className="bg-blue-50 dark:bg-blue-950 p-4 rounded-lg">
                  <h3 className="font-semibold flex items-center mb-2">
                    <Bot className="w-5 h-5 mr-2" />
                    Gerador de Lógicas com IA
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    Descreva em linguagem natural a lógica que você deseja criar e a IA
                    gerará o código JSON ou TXT automaticamente.
                  </p>
                </div>

                <div>
                  <Label>Tipo de Lógica</Label>
                  <div className="flex gap-4 mt-2">
                    <Button
                      variant={selectedType === "json_static" ? "default" : "outline"}
                      onClick={() => setSelectedType("json_static")}
                    >
                      <FileJson className="w-4 h-4 mr-2" />
                      JSON (Estático)
                    </Button>
                    <Button
                      variant={selectedType === "txt_ai" ? "default" : "outline"}
                      onClick={() => setSelectedType("txt_ai")}
                    >
                      <FileText className="w-4 h-4 mr-2" />
                      TXT (IA)
                    </Button>
                  </div>
                </div>

                <div>
                  <Label htmlFor="gemini-prompt">Descreva a Lógica</Label>
                  <Textarea
                    id="gemini-prompt"
                    placeholder={
                      selectedType === "json_static"
                        ? "Ex: Crie uma lógica que responda 'Olá! Como posso ajudar?' quando o usuário enviar 'oi', 'olá' ou 'bom dia'"
                        : "Ex: Crie um assistente que ajuda clientes a escolher produtos de tecnologia, fazendo perguntas sobre necessidades e orçamento"
                    }
                    value={geminiPrompt}
                    onChange={(e) => setGeminiPrompt(e.target.value)}
                    rows={6}
                  />
                </div>

                <Button
                  onClick={handleGenerateLogic}
                  disabled={generateLogicMutation.isPending}
                  className="w-full"
                >
                  {generateLogicMutation.isPending && (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  )}
                  <Bot className="w-4 h-4 mr-2" />
                  Gerar Lógica com IA
                </Button>

                {logicContent && (
                  <div className="space-y-4 pt-4 border-t">
                    <div>
                      <Label htmlFor="generated-name">Nome Gerado</Label>
                      <Input
                        id="generated-name"
                        value={logicName}
                        onChange={(e) => setLogicName(e.target.value)}
                      />
                    </div>

                    <div>
                      <Label htmlFor="generated-content">Conteúdo Gerado</Label>
                      <Textarea
                        id="generated-content"
                        value={logicContent}
                        onChange={(e) => setLogicContent(e.target.value)}
                        rows={10}
                        className="font-mono text-sm"
                      />
                    </div>

                    <Button
                      onClick={handleCreateLogic}
                      disabled={createLogicMutation.isPending}
                      className="w-full"
                    >
                      {createLogicMutation.isPending && (
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      )}
                      <Plus className="w-4 h-4 mr-2" />
                      Salvar Lógica
                    </Button>
                  </div>
                )}
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="list" className="space-y-4">
            {isLoading ? (
              <div className="flex justify-center py-8">
                <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
              </div>
            ) : logics && logics.length > 0 ? (
              <div className="grid gap-4">
                {logics.map((logic) => (
                  <Card key={logic.id} className="p-4">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          {logic.type === "json_static" ? (
                            <FileJson className="w-5 h-5 text-blue-500" />
                          ) : (
                            <FileText className="w-5 h-5 text-green-500" />
                          )}
                          <h3 className="font-semibold">{logic.name}</h3>
                          <span className="text-xs bg-muted px-2 py-1 rounded">
                            {logic.type.toUpperCase()}
                          </span>
                        </div>
                        <pre className="text-sm bg-muted p-3 rounded overflow-x-auto max-h-32">
                          {logic.content}
                        </pre>
                        <p className="text-xs text-muted-foreground mt-2">
                          Criada em: {new Date(logic.createdAt).toLocaleString()}
                        </p>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDeleteLogic(logic.id)}
                        disabled={deleteLogicMutation.isPending}
                      >
                        <Trash2 className="w-4 h-4 text-destructive" />
                      </Button>
                    </div>
                  </Card>
                ))}
              </div>
            ) : (
              <Card className="p-8 text-center">
                <p className="text-muted-foreground">
                  Nenhuma lógica criada ainda. Crie sua primeira lógica!
                </p>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
