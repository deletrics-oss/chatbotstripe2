import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { trpc } from "@/lib/trpc";
import { Loader2, Plus, QrCode, Trash2, Wifi, WifiOff, FileCode } from "lucide-react";
import { Link } from "wouter";
import { useState } from "react";
import { toast } from "sonner";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function Dashboard() {
  const { user, loading: authLoading } = useAuth();
  const [newSessionName, setNewSessionName] = useState("");
  const [newSessionId, setNewSessionId] = useState("");
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  // Queries
  const { data: tenant, isLoading: tenantLoading } = trpc.tenant.get.useQuery();
  const { data: sessions, isLoading: sessionsLoading, refetch: refetchSessions } = trpc.sessions.list.useQuery();

  // Mutations
  const createTenantMutation = trpc.tenant.create.useMutation({
    onSuccess: () => {
      toast.success("Conta configurada com sucesso!");
      window.location.reload();
    },
    onError: (error) => {
      toast.error(`Erro: ${error.message}`);
    },
  });

  const createSessionMutation = trpc.sessions.create.useMutation({
    onSuccess: () => {
      toast.success("Sessão criada com sucesso!");
      setIsDialogOpen(false);
      setNewSessionName("");
      setNewSessionId("");
      refetchSessions();
    },
    onError: (error) => {
      toast.error(`Erro: ${error.message}`);
    },
  });

  const deleteSessionMutation = trpc.sessions.delete.useMutation({
    onSuccess: () => {
      toast.success("Sessão removida com sucesso!");
      refetchSessions();
    },
    onError: (error) => {
      toast.error(`Erro: ${error.message}`);
    },
  });

  const updateLogicMutation = trpc.sessions.updateLogic.useMutation({
    onSuccess: () => {
      toast.success("Lógica atualizada com sucesso!");
      refetchSessions();
    },
    onError: (error) => {
      toast.error(`Erro: ${error.message}`);
    },
  });

  const { data: logics } = trpc.logics.list.useQuery();

  if (authLoading || tenantLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle>Acesso Negado</CardTitle>
            <CardDescription>Você precisa fazer login para acessar o dashboard.</CardDescription>
          </CardHeader>
        </Card>
      </div>
    );
  }

  if (!tenant) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle>Configuração Inicial</CardTitle>
            <CardDescription>
              Bem-vindo! Vamos configurar sua conta com o plano Free (30 dias grátis).
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button
              onClick={() => createTenantMutation.mutate()}
              disabled={createTenantMutation.isPending}
              className="w-full"
            >
              {createTenantMutation.isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              Configurar Conta
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const handleCreateSession = () => {
    if (!newSessionName || !newSessionId) {
      toast.error("Preencha todos os campos");
      return;
    }
    createSessionMutation.mutate({ name: newSessionName, sessionId: newSessionId });
  };

  const handleDeleteSession = (sessionId: string) => {
    if (confirm("Tem certeza que deseja remover esta sessão?")) {
      deleteSessionMutation.mutate({ sessionId });
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "ready":
        return <Wifi className="w-5 h-5 text-green-500" />;
      case "qr_pending":
        return <QrCode className="w-5 h-5 text-yellow-500" />;
      case "disconnected":
      case "destroyed":
        return <WifiOff className="w-5 h-5 text-red-500" />;
      default:
        return <Loader2 className="w-5 h-5 text-gray-500 animate-spin" />;
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case "ready":
        return "Conectado";
      case "qr_pending":
        return "Aguardando QR Code";
      case "disconnected":
        return "Desconectado";
      case "destroyed":
        return "Removido";
      default:
        return "Inicializando";
    }
  };

  return (
    <div className="min-h-screen bg-background p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Dashboard</h1>
          <p className="text-muted-foreground">
            Gerencie suas sessões WhatsApp e chatbots
          </p>
        </div>

        {/* Plan Info */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Informações do Plano</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <p className="text-sm text-muted-foreground">Plano Atual</p>
                <p className="text-lg font-semibold capitalize">{tenant.plan}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Sessões Disponíveis</p>
                <p className="text-lg font-semibold">
                  {sessions?.length || 0} / {tenant.maxSessions}
                </p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Trial Termina Em</p>
                <p className="text-lg font-semibold">
                  {tenant.trialEndsAt
                    ? new Date(tenant.trialEndsAt).toLocaleDateString("pt-BR")
                    : "N/A"}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Sessions */}
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-2xl font-bold">Sessões WhatsApp</h2>
          <div className="flex gap-2">
            <Button asChild variant="outline">
              <Link href="/logics">
                <FileCode className="w-4 h-4 mr-2" />
                Gerenciar Lógicas
              </Link>
            </Button>
            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="w-4 h-4 mr-2" />
                  Nova Sessão
                </Button>
              </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Criar Nova Sessão</DialogTitle>
                <DialogDescription>
                  Crie uma nova sessão WhatsApp para gerenciar seus chatbots.
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="name">Nome da Sessão</Label>
                  <Input
                    id="name"
                    placeholder="Ex: Atendimento Principal"
                    value={newSessionName}
                    onChange={(e) => setNewSessionName(e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="sessionId">ID da Sessão</Label>
                  <Input
                    id="sessionId"
                    placeholder="Ex: atendimento-principal"
                    value={newSessionId}
                    onChange={(e) => setNewSessionId(e.target.value)}
                  />
                  <p className="text-sm text-muted-foreground mt-1">
                    Use apenas letras minúsculas, números e hífens
                  </p>
                </div>
                <Button
                  onClick={handleCreateSession}
                  disabled={createSessionMutation.isPending}
                  className="w-full"
                >
                  {createSessionMutation.isPending && (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  )}
                  Criar Sessão
                </Button>
              </div>
            </DialogContent>
            </Dialog>
          </div>
        </div>

        {sessionsLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : sessions && sessions.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {sessions.map((session) => (
              <Card key={session.id}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">{session.name}</CardTitle>
                    {getStatusIcon(session.status)}
                  </div>
                  <CardDescription>{getStatusText(session.status)}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <p className="text-sm text-muted-foreground">
                      ID: <span className="font-mono">{session.sessionId}</span>
                    </p>
                    <div className="mt-3">
                      <Label className="text-xs">Lógica Associada</Label>
                      <Select
                        value={session.logicId?.toString() || "none"}
                        onValueChange={(value) => {
                          updateLogicMutation.mutate({
                            sessionId: session.sessionId,
                            logicId: value === "none" ? null : parseInt(value),
                          });
                        }}
                      >
                        <SelectTrigger className="w-full mt-1">
                          <SelectValue placeholder="Selecione uma lógica" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="none">Nenhuma</SelectItem>
                          {logics?.map((logic) => (
                            <SelectItem key={logic.id} value={logic.id.toString()}>
                              {logic.name} ({logic.type === "json_static" ? "JSON" : "IA"})
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    {session.status === "qr_pending" && session.qrCode && (
                      <div className="mt-4">
                        <img
                          src={session.qrCode}
                          alt="QR Code"
                          className="w-full rounded-md border"
                        />
                        <p className="text-xs text-center text-muted-foreground mt-2">
                          Escaneie com o WhatsApp
                        </p>
                      </div>
                    )}
                    <Button
                      variant="destructive"
                      size="sm"
                      className="w-full mt-4"
                      onClick={() => handleDeleteSession(session.sessionId)}
                      disabled={deleteSessionMutation.isPending}
                    >
                      <Trash2 className="w-4 h-4 mr-2" />
                      Remover
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card>
            <CardContent className="py-12 text-center">
              <p className="text-muted-foreground">
                Nenhuma sessão criada ainda. Clique em "Nova Sessão" para começar.
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
