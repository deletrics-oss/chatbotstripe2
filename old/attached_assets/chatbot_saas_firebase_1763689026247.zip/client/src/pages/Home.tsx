import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Loader2, Bot, Zap, Shield } from "lucide-react";
import { APP_LOGO, APP_TITLE, getLoginUrl } from "@/const";
import { useEffect } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

/**
 * All content in this page are only for example, replace with your own feature implementation
 * When building pages, remember your instructions in Frontend Workflow, Frontend Best Practices, Design Guide and Common Pitfalls
 */
export default function Home() {
  const { user, loading, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();

  const createCheckoutMutation = trpc.stripe.createCheckout.useMutation({
    onSuccess: (data) => {
      if (data.url) {
        window.open(data.url, "_blank");
        toast.info("Redirecionando para o checkout...");
      }
    },
    onError: (error) => {
      toast.error(`Erro: ${error.message}`);
    },
  });

  useEffect(() => {
    if (isAuthenticated && user) {
      setLocation("/dashboard");
    }
  }, [isAuthenticated, user, setLocation]);

  const handleCheckout = (plan: "basic" | "premium") => {
    if (!isAuthenticated) {
      window.location.href = getLoginUrl();
      return;
    }
    createCheckoutMutation.mutate({ plan });
  };

  // If theme is switchable in App.tsx, we can implement theme toggling like this:
  // const { theme, toggleTheme } = useTheme();

  // Use APP_LOGO (as image src) and APP_TITLE if needed

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      {/* Hero Section */}
      <section className="py-20 px-4 bg-gradient-to-b from-primary/5 to-background">
        <div className="container max-w-6xl mx-auto text-center">
          <h1 className="text-5xl font-bold mb-6">
            Chatbot SaaS Platform
          </h1>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Gerencie seus chatbots WhatsApp com inteligência artificial, lógicas personalizadas e assinaturas flexíveis.
          </p>
          <Button size="lg" asChild>
            <a href={getLoginUrl()}>Comece Agora - Grátis por 30 Dias</a>
          </Button>
        </div>
      </section>

      {/* Features */}
      <section className="py-20 px-4">
        <div className="container max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12">Recursos Principais</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-4">
                <Bot className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Chatbots Inteligentes</h3>
              <p className="text-muted-foreground">
                Crie chatbots com IA Gemini ou lógicas JSON estáticas personalizadas.
              </p>
            </div>
            <div className="text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-4">
                <Zap className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Geração Automática</h3>
              <p className="text-muted-foreground">
                Use IA para gerar lógicas de chatbot automaticamente a partir de descrições.
              </p>
            </div>
            <div className="text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-4">
                <Shield className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Multilocação Segura</h3>
              <p className="text-muted-foreground">
                Cada usuário tem seus dados isolados e protegidos com segurança de nível empresarial.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section className="py-20 px-4 bg-muted/30">
        <div className="container max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12">Planos e Preços</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-card rounded-lg border p-6">
              <h3 className="text-2xl font-bold mb-2">Free</h3>
              <p className="text-3xl font-bold mb-4">R$ 0<span className="text-sm font-normal">/mês</span></p>
              <ul className="space-y-2 mb-6">
                <li className="flex items-center">
                  <span className="mr-2">✓</span> 30 dias grátis
                </li>
                <li className="flex items-center">
                  <span className="mr-2">✓</span> 1 sessão WhatsApp
                </li>
                <li className="flex items-center">
                  <span className="mr-2">✓</span> Lógicas JSON estáticas
                </li>
              </ul>
              <Button variant="outline" className="w-full" asChild>
                <a href={getLoginUrl()}>Começar</a>
              </Button>
            </div>
            <div className="bg-card rounded-lg border-2 border-primary p-6 relative">
              <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-primary text-primary-foreground px-4 py-1 rounded-full text-sm font-semibold">
                Popular
              </div>
              <h3 className="text-2xl font-bold mb-2">Básico</h3>
              <p className="text-3xl font-bold mb-4">R$ 29,90<span className="text-sm font-normal">/mês</span></p>
              <ul className="space-y-2 mb-6">
                <li className="flex items-center">
                  <span className="mr-2">✓</span> 1 sessão WhatsApp
                </li>
                <li className="flex items-center">
                  <span className="mr-2">✓</span> Lógicas JSON estáticas
                </li>
                <li className="flex items-center">
                  <span className="mr-2">✓</span> Suporte prioritário
                </li>
              </ul>
              <Button 
                className="w-full" 
                onClick={() => handleCheckout("basic")}
                disabled={createCheckoutMutation.isPending}
              >
                {createCheckoutMutation.isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                Assinar
              </Button>
            </div>
            <div className="bg-card rounded-lg border p-6">
              <h3 className="text-2xl font-bold mb-2">Premium</h3>
              <p className="text-3xl font-bold mb-4">R$ 99,90<span className="text-sm font-normal">/mês</span></p>
              <ul className="space-y-2 mb-6">
                <li className="flex items-center">
                  <span className="mr-2">✓</span> 3 sessões WhatsApp
                </li>
                <li className="flex items-center">
                  <span className="mr-2">✓</span> Lógicas JSON + IA
                </li>
                <li className="flex items-center">
                  <span className="mr-2">✓</span> Bot inteligente com Gemini
                </li>
                <li className="flex items-center">
                  <span className="mr-2">✓</span> Suporte prioritário
                </li>
              </ul>
              <Button 
                variant="outline" 
                className="w-full"
                onClick={() => handleCheckout("premium")}
                disabled={createCheckoutMutation.isPending}
              >
                {createCheckoutMutation.isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                Assinar
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
